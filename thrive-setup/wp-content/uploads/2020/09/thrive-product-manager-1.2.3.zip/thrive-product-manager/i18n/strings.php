<?php
return array(
	'go_to_TD'            => __( 'Go to the Thrive Themes Dashboard', Thrive_Product_Manager::T ),
	'go_to_TTB_dashboard' => __( 'Go to the Theme Builder Dashboard', Thrive_Product_Manager::T ),
);
