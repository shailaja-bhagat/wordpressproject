=== Contact Form with Ajax ===
Contributors: shailaja
Donate link:
Tags: Data Listing, Admin Data Listing
Requires at least: 3.3
Tested up to: 5.5.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Features ==
1. This plugin mainly creates a table in DB with fields
2. It disaplys all the data in backend listing wise
3. You can Add, Edit, Update data of employee
4. Using this shortcode [display_listing] all the data from database will display in frontend
5. You can also do a search by name in frontend

== Installation ==

1. Upload plugin's zip file to the 'Add New Plugin' section in the WordPress.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place shortcode where you want to display shortcode.